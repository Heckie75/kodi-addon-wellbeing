import xbmcaddon

addon = xbmcaddon.Addon()

if __name__ == "__main__":

    addon.openSettings()
