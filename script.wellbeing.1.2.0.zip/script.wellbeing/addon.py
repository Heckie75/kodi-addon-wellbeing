from resources.lib.wellbeing import wellbeing

if __name__ == "__main__":

    wellbeing = wellbeing.Wellbeing()
    wellbeing.start()
